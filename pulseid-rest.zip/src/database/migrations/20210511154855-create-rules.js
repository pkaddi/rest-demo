'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('rules', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      startDate: {
        type: Sequelize.DATE
      },
      endDate: {
        type: Sequelize.DATE
      },
      redemptionLimit: {
        type: Sequelize.INTEGER
      },
      appliedRedemptions: {
        type: Sequelize.INTEGER
      },
      budgetLimit: {
        type: Sequelize.INTEGER
      },
      appliedBudget: {
        type: Sequelize.INTEGER
      },
      minTransactions: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('rules');
  }
};